## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  out.width = "600px"
)

# --- Protecció per CRAN / win-builder ---
# Si no hi ha internet o estem a CRAN, no avaluem els chunks de l'API
is_cran_check <- !curl::has_internet() || identical(Sys.getenv("NOT_CRAN"), "")

if (is_cran_check) {
  knitr::opts_chunk$set(eval = FALSE)
}

# Funció per no petar si falta un Suggest
has <- function(p) requireNamespace(p, quietly = TRUE)

# Carrega només si existeix, així la vinyeta es pot construir igual
suppressPackageStartupMessages({
  if (has("dplyr")) library(dplyr)
  if (has("tibble")) library(tibble)
  if (has("rminka")) library(rminka)
  if (has("sf")) library(sf)
  if (has("leaflet")) library(leaflet)
  if (has("htmltools")) library(htmltools)
  if (has("purrr")) library(purrr)
  if (has("ggplot2")) library(ggplot2)
  if (has("magick")) library(magick)
})


## ----project1, include = TRUE , echo=TRUE-------------------------------------
# prj_names <- mnk_proj_byname("biomarato 2025")
# 
# prj_names
# 
# # For this example
# 
# prj_names[,c(1:2)]
# 

## ----project_info, include = TRUE , echo=TRUE---------------------------------
# prj_info <- mnk_proj_info(419)
# 
# prj_info
# 

## ----project_info_user, include = TRUE , echo=TRUE----------------------------
# prj_user <- mnk_proj_user(419)
# 
# prj_user
# 

## ----project_info_user2, include = TRUE , echo=TRUE, eval=TRUE----------------
# 1. Download all observations for the project in may 2025

obs_2025 <- mnk_proj_obs(419,year=2025, month = 5, quiet = TRUE)

# 2. Extract the unique participants

participants_may_2025 <- obs_2025 %>%
  distinct(user_login) %>%
  arrange(user_login)

participants_may_2025


## ----project_obs_proj, include = TRUE , echo=TRUE-----------------------------
# prj_obs <- mnk_proj_obs(419, year= 2025, month=5)
# 
# prj_obs[2:14]
# 

## ----user_name, include = TRUE , echo=TRUE------------------------------------
# user_name <- mnk_user_byname("xavi")
# 
# user_name
# 

## ----user_info, include = TRUE , echo=TRUE------------------------------------
# user_info <- mnk_user_info(4)
# 
# user_info
# 

## ----user_project, include = TRUE , echo=TRUE---------------------------------
# user_project <- mnk_user_proj(4)
# 
# user_project
# 

## ----user_obs, include = TRUE , echo=TRUE-------------------------------------
# user_obs <- mnk_user_obs(user_id= 4, year = 2025, month = 8)
# 
# user_obs
# 

## ----place_name, include = TRUE , echo=TRUE-----------------------------------
# places <- mnk_place_byname("Forum")
# 
# places[,1:6]
# 

## ----place_sf, include = TRUE , echo=TRUE-------------------------------------
# # 1. Downloading the geometry
# 
# places_forum <- mnk_place_sf(253)
# 
# # 2. Drawing the map
# 
#  forum_sf <-leaflet(places_forum) %>%
#                 addProviderTiles("OpenStreetMap", group = "OSM") %>%
#                 addProviderTiles("Esri.WorldImagery", group = "Satélite") %>%
#                 addPolygons(
#                   color = "#2c4fb8",
#                   weight = 2,
#                   opacity = 1,
#                   fillOpacity = 0.4,
#                   label = ~name, # information added from previous function
#                   highlightOptions = highlightOptions(weight = 3, bringToFront = TRUE)
#                 ) %>%
#                 addLayersControl(baseGroups = c("Satélite", "OSM"))
#  forum_sf
# 

## ----places_obs, include = TRUE , echo=TRUE-----------------------------------
# obs_place <- mnk_place_obs(place_id = 253, year = 2025, month = 2, quiet = TRUE)
# 
# obs_place
# 
# #Turning the dataframe into an sf object with the mnk_obs_sf() function
# 
# # NUEVO: mnk_place_obs() expone URL_image para mostrar la foto mediana.
# obs_sf <- mnk_obs_sf(obs_place, "id", "taxon_name", "observed_on",
#                      "URL_image", "uri", "user_login")
# 
# # Preparing the obtained data for later display in the marker popup
# 
# popup_final <-  paste0( "ID: <a href='", obs_sf$uri,
#                         "' target='_blank'>",obs_sf$id , "</a><br>",
#                         "Specie:", obs_sf$taxon_name, "<br>",
#                         "Observer: ", obs_sf$user_login,"<br>",
#                         "Date:", obs_sf$observed_on, "<br>",
#                         "<a href='", obs_sf$URL_image, "' target='_blank'><img src='",
#                         obs_sf$URL_image,
#                         "' style='margin-top:2px;border-radius:4px;'> </a> ")
# #finally plotins
# 
# # Only the observations:
# 
# leaflet(obs_sf) %>%
#                 addProviderTiles("OpenStreetMap", group = "OSM") %>%
#                 addProviderTiles("Esri.WorldImagery", group = "Satélite") %>%
#                 addMarkers(lng = ~longitude,
#                            lat = ~latitude,
#                            popup = popup_final) %>%
#                 addLayersControl(baseGroups = c("Satélite", "OSM"))
# 
# #  Observations plus place maping
# 
#  forum_sf %>%
#   addMarkers(data = obs_sf, popup = ~popup_final)
# 

## ----obs_id-------------------------------------------------------------------
# obs_id <- mnk_obs_id(id = 553028)
# 
# obs_id
# 

## ----obs----------------------------------------------------------------------
# #In this example don´t show messages in console (quiet= TRUE)
# 
# # Get observations for genus Raja in 2025 by user Xavier Salvador ( user_id=4)
# 
# obs <- mnk_obs(taxon_name = "Raja", year = 2025, user_id = 4, quiet = TRUE,
#                quality = "research")
# 
# obs # show full dataframe
# 
# # Get observations for species Raja brachyura in 2023 by user Xasalva (user_id= 4)
# 
# obs_brachyura <- mnk_obs(taxon_name = "Raja brachyura", year = 2023, user_id = 4,
#                          quiet = TRUE, quality = "research")
# 
# obs_brachyura[, c(1,2, 10, 11, 16, 27)]  # show selected columns
# 

## ----brachyura-pic, out.width='85%', fig.align='center', fig.alt="Raja undulata observed by Xavier Salvador"----
# # Get observations for specie Raja undulata in 2022 by user Xasalva (user_id= 4)
# 
# obs_undulata <- mnk_obs(taxon_name = "Raja undulata", year = 2022, user_id = 4,
#                          quiet = TRUE, quality = "research")
# 
# # NUEVO: el nombre de la columna original es url_picture_orig.
# # Select the third observation and get its medium-resolution picture URL.
# 
# url_pic_undulata <- as.character(obs_undulata$url_picture_med[3])
# 
# # read image directly from URL
# 
# img_undulata <- image_read(url_pic_undulata )
# 
#   # add copyright caption at bottom
#   img_undulata <- image_annotate(
#     img_undulata,
#     "© Xavier Salvador",
#     size = 15,
#     gravity = "southeast",
#     color = "white",
#   )
# 
# # display image in the document
# 
# img_undulata
# 

## ----obs_1--------------------------------------------------------------------
# 
# # read shapefile of  study area using relative path
# 
# shp_path <- system.file("extdata", "espigo_w.shp", package = "rminka")
# 
# espigo <- sf::st_read(shp_path, quiet = TRUE)
# 
# # ensure WGS84 for leaflet (standard for web maps)
# 
# bounds <- st_transform(espigo, 4326)
# 

## ----bounds-------------------------------------------------------------------
# #Pmin
# xmin <- 2.189147
# ymin <- 41.368182
# 
# #Pmax
# xmax <- 2.193971
# ymax <- 41.371239
# 
# pts <- data.frame(
#   id = c("Pmin", "Pmax"),
#   lng = c(xmin, xmax),
#   lat = c(ymin, ymax)
# )
# 
# # create interactive map for visualising the study area and the two points
# 
# bound <- leaflet() %>%
#                 addProviderTiles("Esri.WorldImagery", group = "Satélite") %>%
#                 addProviderTiles("OpenStreetMap", group = "OSM") %>%
#                 addCircleMarkers(
#                          data = pts,
#                           radius = 20,
#                           color = "cyan",
#                           weight = 2,
#                           fillOpacity = 0.7,
#                           label = ~id,
#                           popup = ~paste0("<b>", id, "</b><br>",
#                                           "lon: ", round(lng, 6), "<br>",
#                                           "lat: ", round(lat, 6))) %>%
#                 addPolygons(data =    bounds,
#                           color = "#2c4fb8",
#                           weight = 2,
#                           opacity = 1,
#                           fillOpacity = 0.4,
#                           label = "Bound Espigo W",
#                           popup = "Bound Espigo W",
#                           highlightOptions = highlightOptions(weight = 3,
#                                                               bringToFront =TRUE)) %>%
#                 addLayersControl(baseGroups = c("Satélite", "OSM"))
# 
# bound  # display map in document
# 
# #Obtaining the observations within the study area
# 
# obs_torpedo_bounds <- mnk_obs(taxon_name = "Torpedo", year = 2024,
#                       bounds = bounds , quality = "research", quiet = TRUE)
# 
# obs_torpedo_bounds
# 
# #Turning the dataframe into an sf object with the mnk_obs_sf() function and
# #selecting some fields ("id","taxon_name","observed_on",.....) from the original
# #data frame for to show later in leaflet popups.
# 
# # NUEVO: conservar la URL original para el enlace y la mediana para mostrar la imagen.
# obs_bounds_sf <- mnk_obs_sf(obs_torpedo_bounds, "id", "taxon_name", "observed_on",
#                             "url_picture_med", "url_picture_orig", "uri", "user_login")
# 
# # Preparing the obtained data for later display in the marker popup
# 
# popup_final_torpedo <-  paste0( "ID: <a href='", obs_bounds_sf$uri,
#                         "' target='_blank'>",obs_bounds_sf$id , "</a><br>",
#                         "Specie:", obs_bounds_sf$taxon_name, "<br>",
#                         "Observer: ", obs_bounds_sf$user_login,"<br>",
#                         "Date:", obs_bounds_sf$observed_on, "<br>",
#                         "<a href='", obs_bounds_sf$url_picture_orig,
#                         "' target='_blank'><img src='",
#                         obs_bounds_sf$url_picture_med,
#                         "' style='margin-top:2px;border-radius:4px;'> </a> ")
# 
# #final plot
# 
# bound %>%
#   addMarkers(data = obs_bounds_sf, popup = ~popup_final_torpedo)
# 

## ----obs_byday----------------------------------------------------------------
# #Retrieves observations for specie Raja undulata by user Xasalva (user_id= 4) the observations between 01-01-2024 and  25-05-2024.
# 
# obs_undulata_2024 <- mnk_obs_byday(taxon_name = "Raja undulata", d1 = "2024-01-01",
#                              d2= "2024-05-25", quiet = TRUE, quality = "research")
# 
# obs_undulata_2024
# 

## ----sf_obs,message=FALSE, warning=FALSE--------------------------------------
# # NUEVO: seleccionar ambas resoluciones para enlazar al original y mostrar la mediana.
# obs_utm <- mnk_obs_sf(obs_torpedo_bounds, id, taxon_name,
#                       observed_on, user_login, quality_grade,
#                       url_picture_med, url_picture_orig,
#                       uri, crs = 25831)
# 
# # The input obs_torpedo_bounds is a data frame with the full set of observation records. The
# #function keeps only the selected attribute columns (id, taxon_name, observed_on, user_login,
# #quality_grade, url_picture_med, url_picture_orig, uri); these are preserved in the output sf object together with
# #the generated geometry in obs_utm.
# 
# #The crs = 25831 parameter overrides the default EPSG:4326.
# #Here we request the output directly in EPSG:25831 – ETRS89 / UTM zone 31N,
# #which is the official projected CRS for Catalonia.
# #This is useful for distance calculations and for matching local cartography
# 
# 
# # Leaflet natively works in Web Mercator (EPSG:3857). To visualize data in UTM,
# #you must change the map's base CRS:
# 
# crs25831 <- leafletCRS(
#   crsClass = "L.Proj.CRS",
#   code = "EPSG:25831",
#   proj4def = "+proj=utm +zone=31 +ellps=GRS80 +units=m +no_defs",
#   resolutions = c(8192,4096,2048,1024,512,256,128,64,32,16,8,4,2,1,0.5),
#   origin = c(0, 9000000)
# )
# 
# # Because the map is no longer in 3857, you cannot use standard OSM tiles.
# #You need a WMS that serves imagery in the same CRS.
# #Here we use the Institut Cartogràfic i Geològic de Catalunya (ICGC) service.
# 
# leaflet(options = leafletOptions(crs25831, minZoom = 0, maxZoom = 14)) %>%
# 
#       addWMSTiles(
#         "https://geoserveis.icgc.cat/servei/catalunya/mapa-base/wms",
#         layers = "orto",
#         options = WMSTileOptions(format = "image/png",
#                                  transparent = TRUE, version = "1.3.0")) %>%
# 
# # NUEVO: el enlace abre la imagen original y el marcador muestra la versión mediana.
#       addCircleMarkers(
#         data = obs_utm,
#         radius = 6,
#         color = "red",
#         fillOpacity = 0.9,
#         popup =  paste0( "ID: <a href='", obs_utm$uri,
#                             "' target='_blank'>",obs_utm$id , "</a><br>",
#                             "Specie:", obs_utm$taxon_name, "<br>",
#                             "Observer: ", obs_utm$user_login,"<br>",
#                             "Quality:", obs_utm$quality_grade,"<br>",
#                             "Date:", obs_utm$observed_on, "<br>",
#                             "<a href='", obs_utm$url_picture_orig,
#                             "' target='_blank'><img src='",
#                             obs_utm$url_picture_med,
#                             "' style='margin-top:2px;border-radius:4px;'> </a> "))

## ----export_mnk---------------------------------------------------------------
# export_mnk_qgis(observations =obs_utm ,file="shape")
# 
# #In this first example we export the observations layer from the previous step (obs_utm)
# #as a single point layer named "observations". The output file is named "shape" — the .gpkg
# #extension is added automatically.Because no path is specified, the file shape.gpkg is saved in the current R working directory of the project.
# 
# tmp1 <- file.path(tempdir(), "shape")
# export_mnk_qgis(observations = obs_utm , file = tmp1)
# 
# 
# 
# #In the second example export several layers at once. Here we write two layers
# #into the same GeoPackage:
# 
# # *  places_forum — a polygon defining the Forum pools area, saved as layer "zone"
# 
# # * obs_sf — point observations from the Forum pools, saved as layer "observations"
# #Both layers are stored in forum.gpkg inside the "examples" folder.
# 

## ----get_taxonom_mnk----------------------------------------------------------
# #First example – single species
# 
# get_wrm_tax("Diplodus sargus")
# 
# #The taxonomy and metadata are retrieved for a single species, Diplodus sargus.
# 
# #Second example – community taxonomy
# #The taxonomy is retrieved for all species observed in the previous `mnk_place_ob`
# #call — all species recorded in the Forum pools area during February 2025 (obs_place).
# 
# taxon_unic <- obs_place %>%
#   filter(!is.na(taxon_name)) %>%
#   distinct(taxon_name) %>%
#   pull(taxon_name)
# 
# taxonomy_df <- map_dfr(
#   setNames(taxon_unic, taxon_unic),
#   ~ get_wrm_tax(.x),
#   .id = "taxon_name"
# )
# 
# #The complete observations tibble for the Forum pools can be rebuilt with taxonomy #information by performing a left_join() between obs_place and the taxonomy dataframe.
# 
# obs_place_tax <- obs_place %>%
#   left_join(taxonomy_df, by = "taxon_name")
# 

## ----shrt_name----------------------------------------------------------------
# #Create standardized abbreviations for scientific names
# 
# obs_place <- obs_place %>%
#   mutate(
#     shrt_tax_name = map_chr(taxon_name, ~ {
#       if (is.na(.x) || .x == "") NA_character_ else shrt_name(.x)
#     })
#   )
# 
# #Count observations per abbreviated species and keep top 10
# 
# freq_top10 <- obs_place %>%
#   filter(!is.na(shrt_tax_name)) %>%          # remove missing names
#   count(shrt_tax_name, name = "n_obs") %>%    # count occurrences
#   slice_max(n_obs, n = 10) %>%                # keep the 10 most frequent
#   arrange(n_obs)
# 
# #Plot horizontal bar chart of observation frequency
# 
# ggplot(freq_top10, aes(x = n_obs, y = reorder(shrt_tax_name, n_obs))) +
#         geom_col(fill = "steelblue") +
#         geom_text(aes(label = n_obs), hjust = -0.2, size = 2) +  # add n as label
#         scale_x_continuous(expand = expansion(mult = c(0, 0.15))) +  # make room for labels
#         labs(
#               x = "Number of observations",
#               y = "Species (abbreviated)",
#               title = "Observation frequency",
#               subtitle = " Forum February 2025"
#             ) +
#         theme_minimal(base_size = 12)

