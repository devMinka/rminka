# utils.R

utils::globalVariables(c(
  "geojson_string",
  "sf_geometry",
  "id",
  "title",
  "description",
  "slug",
  "place_id",
  "icon",
  "header_image_url"
))

#' @importFrom magrittr %>%
NULL

#' @importFrom rlang %||%
NULL

#' @importFrom rlang .data
NULL
